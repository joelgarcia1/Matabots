
#pragma once
#include "vex.h"

extern void Drive();
extern void Arms();
extern void lift();
extern void Gyro_Move();


