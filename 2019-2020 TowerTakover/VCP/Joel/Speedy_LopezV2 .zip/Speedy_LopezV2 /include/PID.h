#pragma once
#include "vex.h"

extern void reset_Enc();
extern void move_baseR();
extern void move_baseL();
extern double InchPerTicks();
extern void PI_straight(double);
