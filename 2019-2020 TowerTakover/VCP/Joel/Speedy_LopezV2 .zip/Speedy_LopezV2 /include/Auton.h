#pragma once
#include "vex.h"

extern void Auton_Strat();